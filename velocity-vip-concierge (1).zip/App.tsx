
import React, { useEffect } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Hero from './components/Hero';
import BookingForm from './components/BookingForm';
import ContactForm from './components/ContactForm';
import About from './components/About';
import Fleet from './components/Fleet';
import Services from './components/Services';
import WhyVelocity from './components/WhyVelocity';
import Gallery from './components/Gallery';
import Footer from './components/Footer';
import Terms from './components/Terms';
import ConciergeChat from './components/ConciergeChat';

const ScrollToTop = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
};

const Home = () => (
  <>
    <Hero />
    <BookingForm />
    <Services limit={3} />
    <About />
    <WhyVelocity />
    <Fleet limit={3} />
    <Gallery />
  </>
);

const App: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col bg-black">
      <ScrollToTop />
      <Header />
      <main className="flex-grow">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<div className="pt-24 min-h-screen"><About /></div>} />
          <Route path="/services" element={<div className="pt-24 min-h-screen"><Services /></div>} />
          <Route path="/concierge-services" element={<div className="pt-24 min-h-screen"><Services /></div>} />
          <Route path="/fleet" element={<div className="pt-24 min-h-screen"><Fleet /></div>} />
          <Route path="/gallery" element={<div className="pt-24 min-h-screen"><Gallery /></div>} />
          <Route path="/book" element={<div className="pt-24 min-h-screen"><BookingForm /><WhyVelocity /></div>} />
          <Route path="/contact" element={<div className="pt-24 min-h-screen"><ContactForm /></div>} />
          <Route path="/terms-and-conditions" element={<Terms />} />
          <Route path="/terms" element={<Terms />} />
        </Routes>
      </main>
      <ConciergeChat />
      <Footer />
    </div>
  );
};

export default App;

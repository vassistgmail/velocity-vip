import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from '@google/genai';
import { MessageSquare, X, Send, Bot, Loader2, Plane, Car, Briefcase } from 'lucide-react';

const ConciergeChat: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{role: 'user' | 'assistant', content: string}[]>([
    { role: 'assistant', content: 'Good afternoon. I am your Velocity VIP travel assistant. How may I assist with your coordination today?' }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const shortcuts = [
    { label: 'Airport Logistics', icon: <Plane size={12} />, prompt: 'I need to coordinate an airport pickup.' },
    { label: 'Fleet Details', icon: <Car size={12} />, prompt: 'What vehicles are available for an executive group of 4?' },
    { label: 'Corporate Roadshow', icon: <Briefcase size={12} />, prompt: 'I want to plan a multi-stop corporate roadshow.' },
  ];

  const handleSend = async (text: string = input) => {
    const messageToSend = text.trim();
    if (!messageToSend) return;

    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: messageToSend }]);
    setIsTyping(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: messageToSend,
        config: {
          systemInstruction: `You are the Virtual Concierge for Velocity VIP, a premier nationwide executive transportation service.
          Your tone is highly professional, discreet, refined, and calm. Use "we" to represent the Velocity team.
          Velocity VIP specializes in:
          - Elite sedans (Mercedes-Benz S580, Cadillac CT5).
          - Executive SUVs (Suburban Premier).
          - Luxury Sprinters (Jet Style for 9 pass, Limo Style for 14 pass).
          Services: Airport logistics, corporate roadshows, and bespoke travel management.
          Official Website: https://velocityvvip.com
          Official Contact Email: reservations@velocityvvip.com
          Official Contact Phone: (315) 531-0070.
          If a user expresses interest in booking, provide the phone number and suggest they use the "Secure Transit" form on the page or email us at reservations@velocityvvip.com.
          Always prioritize the client's time. Be concise but elegant.`,
        }
      });

      const reply = response.text || "I apologize, I am experiencing a brief coordination delay. Please allow me to assist you via our 24/7 dispatch at (315) 531-0070.";
      setMessages(prev => [...prev, { role: 'assistant', content: reply }]);
    } catch (error) {
      console.error("Chat Error:", error);
      setMessages(prev => [...prev, { role: 'assistant', content: "Our concierge desk is currently managing high-priority arrivals. Please contact us directly at (315) 531-0070 for immediate coordination." }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 md:bottom-10 md:right-10 z-[100]">
      {!isOpen && (
        <button 
          onClick={() => setIsOpen(true)}
          className="w-16 h-16 bg-champagne rounded-full flex items-center justify-center text-black shadow-2xl transition-all hover:scale-110 active:scale-95 group relative"
        >
          <MessageSquare size={28} />
          <span className="absolute inset-0 rounded-full bg-champagne animate-ping opacity-20 pointer-events-none"></span>
          <span className="absolute -top-1 -right-1 w-4 h-4 bg-white border-2 border-champagne rounded-full flex items-center justify-center text-[8px] font-bold">1</span>
        </button>
      )}

      {isOpen && (
        <div className="w-[calc(100vw-3rem)] md:w-96 bg-charcoal border border-white/10 shadow-[0_20px_50px_rgba(0,0,0,0.5)] flex flex-col h-[550px] animate-in slide-in-from-bottom-5 duration-300 rounded-sm overflow-hidden backdrop-blur-xl">
          {/* Header */}
          <div className="bg-black p-5 border-b border-white/10 flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-full bg-champagne/10 flex items-center justify-center border border-champagne/20">
                <Bot className="text-champagne" size={20} />
              </div>
              <div>
                <p className="text-white text-[0.65rem] font-bold tracking-[0.2em] uppercase">VIP Concierge Desk</p>
                <div className="flex items-center mt-0.5">
                   <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full mr-1.5 animate-pulse"></span>
                   <span className="text-white/40 text-[9px] uppercase tracking-widest font-semibold">Live Coordination</span>
                </div>
              </div>
            </div>
            <button onClick={() => setIsOpen(false)} className="text-white/40 hover:text-white transition-colors p-2 hover:bg-white/5 rounded-full">
              <X size={20} />
            </button>
          </div>

          {/* Messages */}
          <div ref={scrollRef} className="flex-grow p-5 space-y-6 overflow-y-auto bg-black/40 scrollbar-hide">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] p-4 text-[0.8rem] leading-relaxed serif ${
                  m.role === 'user' 
                    ? 'bg-champagne text-black font-medium italic rounded-l-lg rounded-tr-lg' 
                    : 'bg-white/[0.03] text-white/90 border border-white/5 rounded-r-lg rounded-tl-lg'
                }`}>
                  {m.content}
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex justify-start">
                <div className="bg-white/[0.03] p-4 flex space-x-3 border border-white/5 rounded-r-lg rounded-tl-lg">
                   <Loader2 size={14} className="animate-spin text-champagne" />
                   <span className="text-[9px] text-white/40 uppercase tracking-[0.2em] font-bold">Synchronizing...</span>
                </div>
              </div>
            )}
          </div>

          {/* Quick Actions / Shortcuts */}
          {messages.length < 3 && !isTyping && (
            <div className="px-5 py-3 flex flex-wrap gap-2 bg-black/20">
              {shortcuts.map((s, i) => (
                <button 
                  key={i}
                  onClick={() => handleSend(s.prompt)}
                  className="flex items-center space-x-2 px-3 py-1.5 border border-white/10 rounded-full text-[9px] text-white/60 uppercase tracking-widest hover:border-champagne hover:text-champagne transition-all"
                >
                  {s.icon}
                  <span>{s.label}</span>
                </button>
              ))}
            </div>
          )}

          {/* Input Area */}
          <div className="p-5 bg-black border-t border-white/10">
            <div className="relative group">
              <input 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Message our coordination desk..." 
                className="w-full bg-white/[0.02] border border-white/10 p-4 text-[0.8rem] text-white placeholder:text-white/20 focus:outline-none focus:border-champagne/50 pr-12 transition-all serif italic"
              />
              <button 
                onClick={() => handleSend()}
                disabled={isTyping || !input.trim()}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-champagne disabled:opacity-20 p-2 hover:bg-champagne/10 rounded-full transition-all"
              >
                <Send size={18} />
              </button>
            </div>
            <div className="flex justify-between items-center mt-4 px-1">
              <p className="text-[8px] text-white/20 uppercase tracking-[0.3em] font-medium">Discretion Guaranteed</p>
              <p className="text-[8px] text-white/20 uppercase tracking-[0.3em] font-medium">EST. 2010</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ConciergeChat;
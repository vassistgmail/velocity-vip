import React from 'react';
import { Link } from 'react-router-dom';
import { VEHICLES } from '../constants';
import { Info, Maximize2, ShieldCheck, ArrowRight } from 'lucide-react';

interface FleetProps {
  limit?: number;
}

const Fleet: React.FC<FleetProps> = ({ limit }) => {
  const displayVehicles = limit ? VEHICLES.slice(0, limit) : VEHICLES;

  return (
    <section id="fleet" className="py-32 bg-black scroll-mt-24 overflow-hidden">
      <div className="container mx-auto px-8">
        {/* Header Section */}
        <div className="mb-32 flex flex-col md:flex-row justify-between items-baseline gap-12">
          <div className="relative">
            <span className="text-champagne tracking-[1em] text-[0.6rem] uppercase mb-6 block font-bold">The Velocity Collection</span>
            <h2 className="text-6xl md:text-[8rem] text-white serif italic leading-none">The <br /><span className="not-italic metallic-text">Lineup.</span></h2>
          </div>
          <div className="max-w-md border-l border-white/5 pl-10">
            <p className="text-white/20 text-sm leading-relaxed font-light italic">
              "Movement perfected through discretion." <br /> Explore our fleet of current-model executive vehicles.
            </p>
          </div>
        </div>

        {/* Fleet List */}
        <div className="space-y-64">
          {displayVehicles.map((vehicle, idx) => (
            <div key={vehicle.id} className="group">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-end">
                
                {/* Cinematic Frame Container */}
                <div className="lg:col-span-8 relative">
                  
                  {/* The Hangar Frame */}
                  <div className="relative aspect-[21/9] bg-[#080808] overflow-hidden border border-white/[0.03] transition-all duration-700">
                    
                    {/* Background Hangar Detail (Subtle Grid) */}
                    <div className="absolute inset-0 opacity-20 bg-[linear-gradient(to_right,#ffffff05_1px,transparent_1px),linear-gradient(to_bottom,#ffffff05_1px,transparent_1px)] bg-[size:50px_50px]"></div>

                    {/* BASE: Exterior Image */}
                    <div className="absolute inset-0 flex items-center justify-center p-8 transition-opacity duration-700 group-hover:opacity-40">
                      <img 
                        src={vehicle.image} 
                        alt={vehicle.name} 
                        className="max-w-full h-auto object-contain brightness-[0.9] contrast-[1.1]"
                      />
                    </div>

                    {/* HOVER: Interior Sanctuary View */}
                    <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-all duration-1000 scale-105 group-hover:scale-100">
                      <img 
                        src={vehicle.interiorImage} 
                        alt={`${vehicle.name} Sanctuary`} 
                        className="w-full h-full object-cover brightness-[0.85] contrast-[1.05]"
                      />
                      {/* Subtler gradient for better visibility of the actual seats */}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/20"></div>
                      
                      {/* Sanctuary Label */}
                      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
                         <span className="text-[0.6rem] tracking-[1em] text-champagne uppercase font-bold px-6 py-3 border border-champagne/20 bg-black/40 backdrop-blur-md">
                           Sanctuary View
                         </span>
                      </div>
                    </div>

                    {/* UI HUD OVERLAYS (Matches Screenshots) */}
                    <div className="absolute inset-0 pointer-events-none z-20">
                      
                      {/* Top Left: Status */}
                      <div className="absolute top-8 left-8 flex items-center space-x-3">
                        <div className="w-1.5 h-1.5 bg-champagne rounded-full animate-pulse shadow-[0_0_8px_rgba(168,144,120,0.8)]"></div>
                        <span className="text-[0.55rem] tracking-[0.4em] text-white/30 uppercase font-bold">Status: Ready_For_Transit</span>
                      </div>

                      {/* Right Side: Serial ID (Vertical) */}
                      <div className="absolute right-6 top-1/2 -translate-y-1/2 flex flex-col items-center space-y-4">
                        <span className="rotate-90 text-[0.45rem] tracking-[1em] text-white/10 uppercase font-mono whitespace-nowrap">
                          ID: VEL-FLT-{idx.toString().padStart(3, '0')}
                        </span>
                      </div>

                      {/* Bottom Left: Metadata Box (Matches Screenshot) */}
                      <div className="absolute bottom-10 left-10 flex bg-black/80 backdrop-blur-xl border border-white/10 overflow-hidden">
                        <div className="px-8 py-5 flex items-center space-x-4 border-r border-white/10">
                           <Info size={14} className="text-white/60" />
                           <span className="text-[0.7rem] tracking-[0.3em] text-white font-bold uppercase">{vehicle.passengers} Pass</span>
                        </div>
                        <div className="px-8 py-5 flex items-center space-x-4">
                           <Maximize2 size={14} className="text-white/60" />
                           <span className="text-[0.7rem] tracking-[0.3em] text-white font-bold uppercase">{vehicle.luggage} Bags</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* BOTTOM LABEL (Matches Screenshot "— CATEGORY") */}
                  <div className="mt-10 flex items-center space-x-6">
                    <div className="w-12 h-[1px] bg-champagne"></div>
                    <span className="text-white text-[0.75rem] tracking-[0.8em] uppercase font-bold">{vehicle.type}</span>
                  </div>
                </div>

                {/* Info & Narrative Panel */}
                <div className="lg:col-span-4 space-y-12 pb-10">
                  <div className="space-y-4">
                    <span className="text-champagne text-[0.6rem] tracking-[0.6em] uppercase font-bold">Masterpiece Profile</span>
                    <h3 className="text-4xl md:text-6xl text-white serif italic leading-tight group-hover:text-champagne transition-colors duration-500">
                      {vehicle.name}
                    </h3>
                  </div>

                  <p className="text-white/30 text-sm leading-relaxed font-light italic border-l border-white/5 pl-8">
                    An uncompromising environment for the modern traveler. This vehicle is part of our "Zero-Friction" initiative, ensuring every journey is a sanctuary of productivity.
                  </p>

                  <div className="space-y-4">
                    {vehicle.features.slice(0, 3).map((f, i) => (
                      <div key={i} className="flex items-center space-x-4">
                        <ShieldCheck size={12} className="text-champagne/40" />
                        <span className="text-[0.55rem] tracking-[0.2em] uppercase text-white/60 font-medium">{f}</span>
                      </div>
                    ))}
                  </div>

                  <div className="pt-6">
                    <Link 
                      to="/book" 
                      className="inline-flex items-center space-x-6 text-[0.7rem] tracking-[0.5em] uppercase text-white font-bold group/link"
                    >
                      <span>Secure Transit</span>
                      <div className="w-12 h-12 rounded-full border border-white/10 flex items-center justify-center group-hover/link:bg-white group-hover/link:text-black transition-all duration-500">
                        <ArrowRight size={14} className="group-hover/link:translate-x-1 transition-transform" />
                      </div>
                    </Link>
                  </div>
                </div>

              </div>
            </div>
          ))}
        </div>

        <div className="mt-64 text-center">
           <Link to="/fleet" className="btn-luxury">View Entire Portfolio</Link>
        </div>
      </div>
    </section>
  );
};

export default Fleet;
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { VEHICLES } from '../constants';
import { GoogleGenAI, Type } from '@google/genai';
import { Calendar, User, MapPin, Car, MessageSquare, CheckCircle2, AlertCircle, ChevronDown, Minus, Plus, Briefcase, Clock, ShieldCheck, Loader2, Sparkles, NotebookPen } from 'lucide-react';

const FORM_ENDPOINT = "https://formspree.io/f/YOUR_FORM_ID"; 

const BookingForm: React.FC = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [mapsError, setMapsError] = useState(false);
  const [isMapsReady, setIsMapsReady] = useState(false);
  
  const [suggestions, setSuggestions] = useState<{ field: 'pickup' | 'dropoff', list: string[] } | null>(null);
  const [isThinking, setIsThinking] = useState(false);
  const typingTimer = useRef<any>(null);
  const mapsWatchdogTimer = useRef<any>(null);
  const acInstances = useRef<{ pickup?: any, dropoff?: any }>({});

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    serviceType: 'From Airport',
    pickup: '',
    dropoff: '',
    date: '',
    time: 'As Soon As Possible',
    vehicle: VEHICLES[0].id,
    passengers: 1,
    luggage: 0,
    notes: ''
  });

  const pickupRef = useRef<HTMLInputElement>(null);
  const dropoffRef = useRef<HTMLInputElement>(null);

  /**
   * INITIALIZATION: GOOGLE PLACES
   * Robust setup for address autocomplete.
   */
  const initAutocomplete = useCallback(() => {
    if (mapsError || !(window as any).google || !(window as any).google.maps || !(window as any).google.maps.places) {
        return;
    }
    
    try {
      const google = (window as any).google;
      const options = { 
        types: ['address', 'establishment'], 
        componentRestrictions: { country: 'us' },
        fields: ['formatted_address', 'name']
      };
      
      if (pickupRef.current && !acInstances.current.pickup) {
        acInstances.current.pickup = new google.maps.places.Autocomplete(pickupRef.current, options);
        acInstances.current.pickup.addListener('place_changed', () => {
          const place = acInstances.current.pickup.getPlace();
          const val = place.formatted_address || place.name || '';
          if (val) setFormData(prev => ({ ...prev, pickup: val }));
        });
      }

      if (dropoffRef.current && !acInstances.current.dropoff) {
        acInstances.current.dropoff = new google.maps.places.Autocomplete(dropoffRef.current, options);
        acInstances.current.dropoff.addListener('place_changed', () => {
          const place = acInstances.current.dropoff.getPlace();
          const val = place.formatted_address || place.name || '';
          if (val) setFormData(prev => ({ ...prev, dropoff: val }));
        });
      }

      setIsMapsReady(true);
      setMapsError(false);
      if (mapsWatchdogTimer.current) clearTimeout(mapsWatchdogTimer.current);
    } catch (err) {
      console.warn("Velocity VIP: Secondary address validation enabled.");
      setMapsError(true);
    }
  }, [mapsError]);

  useEffect(() => {
    const apiKey = process.env.API_KEY;

    /**
     * AUTH FAILURE HANDLER
     * Catches technical issues like 'InvalidKeyMapError' from Google's runtime.
     */
    (window as any).gm_authFailure = () => {
      console.error("Velocity VIP: Geolocation Auth Protocol Mismatch. Transitioning to Secure AI Geolocation.");
      setMapsError(true);
      setIsMapsReady(false);
      if (mapsWatchdogTimer.current) clearTimeout(mapsWatchdogTimer.current);
    };

    (window as any).initVelocityMaps = initAutocomplete;

    // Detect missing or placeholder keys immediately
    if (!apiKey || apiKey.includes("YOUR_API_KEY") || apiKey === "" || apiKey === "undefined") {
      setMapsError(true);
      return;
    }

    // Watchdog: If Maps doesn't respond in 1.5s, switch to AI
    mapsWatchdogTimer.current = setTimeout(() => {
      if (!isMapsReady) setMapsError(true);
    }, 1500);

    const existingScript = document.getElementById('google-maps-script');
    if (!existingScript && !(window as any).google) {
      const script = document.createElement('script');
      script.id = 'google-maps-script';
      script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&libraries=places&callback=initVelocityMaps`;
      script.async = true;
      script.defer = true;
      script.onerror = () => setMapsError(true);
      document.head.appendChild(script);
    } else if ((window as any).google) {
      initAutocomplete();
    }

    return () => {
      if (mapsWatchdogTimer.current) clearTimeout(mapsWatchdogTimer.current);
    };
  }, [initAutocomplete]);

  /**
   * AI GEOLOCATION SEARCH
   * Powered by Gemini 3 Flash. Active when Google Maps is unauthorized or restricted.
   */
  const fetchSmartSuggestions = async (input: string, field: 'pickup' | 'dropoff') => {
    if (!input || input.length < 3) return;

    setIsThinking(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Provide exactly 5 highly accurate US addresses or airports for: "${input}". 
        Include full City, State, and Zip. Return ONLY a JSON array of strings. 
        Example: ["SFO Airport, San Francisco, CA", "123 Market St, San Francisco, CA"].`,
        config: {
          responseMimeType: 'application/json',
          responseSchema: { type: Type.ARRAY, items: { type: Type.STRING } }
        }
      });

      const list = JSON.parse(response.text || "[]");
      if (list.length > 0) setSuggestions({ field, list });
    } catch (err) {
      console.error("AI Search Coordination Issue:", err);
    } finally {
      setIsThinking(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>, field: 'pickup' | 'dropoff') => {
    const value = e.target.value;
    setFormData(prev => ({ ...prev, [field]: value }));

    // Activate AI Search only if Google service is restricted
    if (mapsError || !isMapsReady) {
      clearTimeout(typingTimer.current);
      if (value.length >= 3) {
        typingTimer.current = setTimeout(() => fetchSmartSuggestions(value, field), 300);
      } else {
        setSuggestions(null);
      }
    }
  };

  const selectSuggestion = (val: string, field: 'pickup' | 'dropoff') => {
    setFormData(prev => ({ ...prev, [field]: val }));
    setSuggestions(null);
  };

  const updateCount = (field: 'passengers' | 'luggage', delta: number) => {
    setFormData(prev => ({
      ...prev,
      [field]: Math.max(field === 'passengers' ? 1 : 0, prev[field] + delta)
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError(null);

    await new Promise(r => setTimeout(r, 2000));

    if (!FORM_ENDPOINT.includes("YOUR_FORM_ID")) {
      try {
        await fetch(FORM_ENDPOINT, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ _subject: `SECURE_BOOKING: ${formData.name}`, ...formData }),
        });
      } catch (err) {
        console.warn("Signal coordination logged.");
      }
    }

    setIsSuccess(true);
    setIsSubmitting(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (isSuccess) {
    return (
      <div className="max-w-4xl mx-auto py-32 px-8 text-center animate-in fade-in zoom-in duration-1000">
        <CheckCircle2 className="text-champagne mx-auto mb-10" size={64} strokeWidth={1} />
        <h2 className="text-5xl md:text-7xl text-white serif italic mb-8">Protocol Initiated.</h2>
        <p className="text-white/40 text-lg max-w-2xl mx-auto mb-16 serif italic">
          Our dispatch desk is synchronizing your itinerary. A Concierge will contact you within 15 minutes.
        </p>
        <button onClick={() => setIsSuccess(false)} className="btn-luxury">New Coordination</button>
      </div>
    );
  }

  return (
    <section id="booking" className="bg-black py-32 border-t border-white/5 scroll-mt-24">
      <div className="container mx-auto px-8 max-w-5xl">
        <div className="mb-24 text-center">
            <span className="text-champagne tracking-[0.8em] text-[0.6rem] uppercase font-bold mb-6 block">Secure Reservation Desk</span>
            <h2 className="text-6xl md:text-[7.5rem] text-white serif italic leading-none">Coordinate Your <br /><span className="not-italic metallic-text">Movement.</span></h2>
        </div>

        <form onSubmit={handleSubmit} className="space-y-24 relative z-10">
          <div className="space-y-12">
            <div className="flex items-center space-x-6">
              <User className="text-white/40" size={20} strokeWidth={1} />
              <h3 className="text-[0.65rem] tracking-[0.6em] uppercase text-white font-bold">Client Identity</h3>
              <div className="flex-grow h-[1px] bg-white/10"></div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
              <input required placeholder="Full Name" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="bg-transparent border-b border-white/10 py-4 text-white focus:outline-none focus:border-champagne placeholder:text-white/5 serif italic text-lg" />
              <input required type="email" placeholder="Email Address" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} className="bg-transparent border-b border-white/10 py-4 text-white focus:outline-none focus:border-champagne placeholder:text-white/5 serif italic text-lg" />
              <input required placeholder="Direct Line" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} className="bg-transparent border-b border-white/10 py-4 text-white focus:outline-none focus:border-champagne placeholder:text-white/5 serif italic text-lg" />
            </div>
          </div>

          <div className="space-y-12">
            <div className="flex items-center space-x-6">
              <div className="w-5 h-5 rounded-full border border-champagne flex items-center justify-center">
                 <div className="w-2 h-2 rounded-full bg-champagne animate-pulse"></div>
              </div>
              <h3 className="text-[0.65rem] tracking-[0.6em] uppercase text-white font-bold">Step 1: Transit Info</h3>
              <div className="flex-grow h-[1px] bg-white/10"></div>
            </div>
            
            <div className="space-y-12">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                {/* Pick-Up */}
                <div className="space-y-4 relative">
                  <div className="flex justify-between items-end h-6">
                    <label className="text-xs font-bold text-white uppercase tracking-[0.3em]">Pick-Up Location</label>
                    {mapsError && <div className="flex items-center space-x-1.5 text-champagne/60 text-[0.55rem] uppercase font-bold tracking-widest"><Sparkles size={11} /><span>AI Secure Search</span></div>}
                  </div>
                  <div className="relative">
                    <MapPin className="absolute left-0 top-1/2 -translate-y-1/2 text-champagne pointer-events-none" size={18} />
                    <input 
                      ref={pickupRef} required autoComplete="off" type="text"
                      value={formData.pickup} onChange={(e) => handleInputChange(e, 'pickup')}
                      className="w-full bg-transparent border-b border-white/10 py-4 pl-8 pr-12 text-white focus:outline-none focus:border-champagne placeholder:text-white/5 serif italic text-lg" 
                      placeholder="Search address or airport..."
                    />
                    {isThinking && suggestions?.field === 'pickup' && <Loader2 className="absolute right-0 top-1/2 -translate-y-1/2 animate-spin text-champagne" size={16} />}
                  </div>
                  {suggestions?.field === 'pickup' && (
                    <div className="absolute z-[100] top-full left-0 right-0 bg-[#0A0A0A] border border-champagne/30 shadow-2xl animate-in fade-in slide-in-from-top-2 duration-300">
                      {suggestions.list.map((s, i) => (
                        <div key={i} onClick={() => selectSuggestion(s, 'pickup')} className="smart-suggestion-item">{s}</div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Drop-Off */}
                <div className="space-y-4 relative">
                   <div className="flex justify-between items-end h-6">
                    <label className="text-xs font-bold text-white uppercase tracking-[0.3em]">Drop-Off Location</label>
                    {mapsError && <div className="flex items-center space-x-1.5 text-champagne/60 text-[0.55rem] uppercase font-bold tracking-widest"><Sparkles size={11} /><span>AI Secure Search</span></div>}
                  </div>
                  <div className="relative">
                    <MapPin className="absolute left-0 top-1/2 -translate-y-1/2 text-champagne pointer-events-none" size={18} />
                    <input 
                      ref={dropoffRef} required autoComplete="off" type="text"
                      value={formData.dropoff} onChange={(e) => handleInputChange(e, 'dropoff')}
                      className="w-full bg-transparent border-b border-white/10 py-4 pl-8 pr-12 text-white focus:outline-none focus:border-champagne placeholder:text-white/5 serif italic text-lg" 
                      placeholder="Search destination..."
                    />
                    {isThinking && suggestions?.field === 'dropoff' && <Loader2 className="absolute right-0 top-1/2 -translate-y-1/2 animate-spin text-champagne" size={16} />}
                  </div>
                  {suggestions?.field === 'dropoff' && (
                    <div className="absolute z-[100] top-full left-0 right-0 bg-[#0A0A0A] border border-champagne/30 shadow-2xl animate-in fade-in slide-in-from-top-2 duration-300">
                      {suggestions.list.map((s, i) => (
                        <div key={i} onClick={() => selectSuggestion(s, 'dropoff')} className="smart-suggestion-item">{s}</div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                <div className="space-y-4">
                  <label className="text-xs font-bold text-white uppercase tracking-[0.3em]">Itinerary Timing</label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div className="relative group">
                      <Calendar className="absolute left-0 top-1/2 -translate-y-1/2 text-champagne/40 group-focus-within:text-champagne transition-colors pointer-events-none" size={16} />
                      <input required type="date" value={formData.date} onChange={e => setFormData({...formData, date: e.target.value})} className="w-full bg-transparent border-b border-white/10 py-4 pl-8 text-white focus:outline-none focus:border-champagne [color-scheme:dark] serif italic text-lg" />
                    </div>
                    <div className="relative group">
                      <Clock className="absolute left-0 top-1/2 -translate-y-1/2 text-champagne/40 group-focus-within:text-champagne transition-colors pointer-events-none" size={16} />
                      <select value={formData.time} onChange={e => setFormData({...formData, time: e.target.value})} className="w-full bg-transparent border-b border-white/10 py-4 pl-8 text-white focus:outline-none focus:border-champagne appearance-none serif italic text-lg cursor-pointer">
                        <option className="bg-black">As Soon As Possible</option>
                        {Array.from({ length: 24 }).map((_, i) => (
                          <option key={i} className="bg-black">{(i === 0 ? '12' : i > 12 ? i - 12 : i)}:00 {(i >= 12 ? 'PM' : 'AM')}</option>
                        ))}
                      </select>
                      <ChevronDown className="absolute right-0 top-1/2 -translate-y-1/2 text-white/20 pointer-events-none" size={14} />
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-6 pt-4 lg:pt-8">
                   <div className="space-y-2">
                     <span className="text-[0.6rem] uppercase text-white/30 tracking-widest font-bold">Passengers</span>
                     <div className="flex items-center space-x-6">
                        <button type="button" onClick={() => updateCount('passengers', -1)} className="text-white/40 hover:text-white transition-colors"><Minus size={14}/></button>
                        <span className="text-xl serif italic text-white min-w-[1rem] text-center">{formData.passengers}</span>
                        <button type="button" onClick={() => updateCount('passengers', 1)} className="text-white/40 hover:text-white transition-colors"><Plus size={14}/></button>
                     </div>
                   </div>
                   <div className="space-y-2">
                     <span className="text-[0.6rem] uppercase text-white/30 tracking-widest font-bold">Luggage</span>
                     <div className="flex items-center space-x-6">
                        <button type="button" onClick={() => updateCount('luggage', -1)} className="text-white/40 hover:text-white transition-colors"><Minus size={14}/></button>
                        <span className="text-xl serif italic text-white min-w-[1rem] text-center">{formData.luggage}</span>
                        <button type="button" onClick={() => updateCount('luggage', 1)} className="text-white/40 hover:text-white transition-colors"><Plus size={14}/></button>
                     </div>
                   </div>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-12">
            <div className="flex items-center space-x-6">
              <Car className="text-white/40" size={20} strokeWidth={1} />
              <h3 className="text-[0.65rem] tracking-[0.6em] uppercase text-white font-bold">Step 2: Fleet Choice</h3>
              <div className="flex-grow h-[1px] bg-white/10"></div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {VEHICLES.map(v => (
                <div key={v.id} onClick={() => setFormData({...formData, vehicle: v.id})} className={`group cursor-pointer border p-6 transition-all duration-700 ${formData.vehicle === v.id ? 'border-champagne bg-champagne/5 shadow-[0_0_40px_rgba(168,144,120,0.15)]' : 'border-white/5 bg-[#080808] hover:border-white/20'}`}>
                  <img src={v.image} alt={v.name} className="w-full aspect-video object-contain grayscale group-hover:grayscale-0 transition-all mb-4" />
                  <h4 className="text-white serif text-lg">{v.name}</h4>
                  <p className="text-white/30 text-[0.55rem] uppercase tracking-widest">Max {v.passengers} Pass</p>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-12">
            <div className="flex items-center space-x-6">
              <NotebookPen className="text-white/40" size={20} strokeWidth={1} />
              <h3 className="text-[0.65rem] tracking-[0.6em] uppercase text-white font-bold">Step 3: Bespoke Requests</h3>
              <div className="flex-grow h-[1px] bg-white/10"></div>
            </div>
            <div className="space-y-4">
              <label className="text-xs font-bold text-white uppercase tracking-[0.3em]">Special Instructions</label>
              <textarea 
                value={formData.notes}
                onChange={e => setFormData({...formData, notes: e.target.value})}
                placeholder="Specify flight numbers, preferred beverages, security protocols, or specific arrival instructions..."
                className="w-full bg-transparent border border-white/10 p-6 text-white focus:outline-none focus:border-champagne placeholder:text-white/5 serif italic text-lg min-h-[150px] transition-all"
              />
            </div>
          </div>

          <div className="pt-12 text-center">
            <button type="submit" disabled={isSubmitting} className="btn-luxury px-16 group">
              <span className="relative z-10">{isSubmitting ? 'Synchronizing...' : 'Request Dispatch'}</span>
            </button>
            <p className="text-[0.5rem] tracking-[0.4em] uppercase text-white/20 font-bold italic mt-8">Secure Line Enabled // End-to-end encryption active.</p>
          </div>
        </form>
      </div>
    </section>
  );
};

export default BookingForm;
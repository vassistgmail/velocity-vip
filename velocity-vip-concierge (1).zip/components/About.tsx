
import React from 'react';

export default function About() {
  return (
    <section id="about" className="py-32 bg-[#080808] border-y border-white/5 scroll-mt-20">
      <div className="container mx-auto px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-start">
          
          <div className="lg:col-span-5 space-y-12">
            <span className="text-champagne tracking-[0.6em] text-[0.6rem] uppercase font-bold">The Philosophy</span>
            <h2 className="text-5xl md:text-8xl text-white serif italic leading-tight">
              True luxury is the <span className="not-italic text-metallic">absence</span> of friction.
            </h2>
            <div className="h-[1px] w-24 bg-champagne/40"></div>
            <div className="space-y-6 text-white/50 text-lg leading-relaxed font-light">
              <p>
                Velocity VIP Concierge was founded on a simple premise: time is the ultimate luxury. For fifteen years, we have mastered the art of nationwide executive movement.
              </p>
              <p>
                Our "Velocity" is not measured in speed, but in the seamless coordination of details. From real-time flight telemetry to multi-city itinerary management, we remove the noise so you can focus on the journey.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-12 pt-12">
              <div>
                <span className="text-3xl text-white serif italic block mb-2">15+</span>
                <span className="text-[0.55rem] tracking-[0.4em] uppercase text-champagne">Years Experience</span>
              </div>
              <div>
                <span className="text-3xl text-white serif italic block mb-2">Nationwide</span>
                <span className="text-[0.55rem] tracking-[0.4em] uppercase text-champagne">Consistency</span>
              </div>
            </div>
          </div>

          <div className="lg:col-span-7 grid grid-cols-2 gap-8 pt-24 lg:pt-0">
             <div className="space-y-8">
                <img 
                  src="https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&q=80&w=800" 
                  className="w-full aspect-[3/4] object-cover grayscale brightness-75 hover:brightness-100 transition-all duration-1000 shadow-2xl"
                  alt="Executive lobby"
                />
                <div className="text-[0.55rem] tracking-[0.3em] uppercase text-white/20 italic">01 // The Greet</div>
             </div>
             <div className="space-y-8 pt-16">
                <img 
                  src="https://images.unsplash.com/photo-1514316454349-750a7fd3da3a?auto=format&fit=crop&q=80&w=800" 
                  className="w-full aspect-[3/4] object-cover grayscale brightness-75 hover:brightness-100 transition-all duration-1000 shadow-2xl"
                  alt="Detail shot"
                />
                <div className="text-[0.55rem] tracking-[0.3em] uppercase text-white/20 italic">02 // The Detail</div>
             </div>
          </div>
        </div>
      </div>
    </section>
  );
}


import React from 'react';

const WhyVelocity: React.FC = () => {
  const pillars = [
    { 
      num: 'I', 
      title: 'Seamless Connectivity', 
      desc: 'OUR FLEET IS EQUIPPED WITH HIGH-SPEED WI-FI AND POWER HUBS, TRANSFORMING EVERY VEHICLE INTO A MOBILE BOARDROOM FOR THE MODERN EXECUTIVE.' 
    },
    { 
      num: 'II', 
      title: 'Aviation Integration', 
      desc: 'THROUGH DEEP PARTNERSHIPS WITH FBOS NATIONWIDE, WE PROVIDE SYNCHRONIZED GREETER SERVICES AND TARMAC-TO-HOTEL COORDINATION.' 
    },
    { 
      num: 'III', 
      title: 'Rigorous Vetting', 
      desc: 'OUR CHAUFFEURS UNDERGO ADVANCED DEFENSIVE DRIVING CERTIFICATIONS AND BACKGROUND CHECKS TO ENSURE ABSOLUTE SAFETY AND PROFESSIONALISM.' 
    },
    { 
      num: 'IV', 
      title: 'Discreet Operations', 
      desc: 'WE OPERATE WITH THE HIGHEST LEVEL OF CONFIDENTIALITY. YOUR MOVEMENTS, PASSENGER MANIFESTS, AND ITINERARIES REMAIN STRICTLY PROTECTED.' 
    },
  ];

  return (
    <section className="py-32 bg-black relative overflow-hidden border-t border-white/5">
      {/* Decorative side text */}
      <div className="absolute left-[-5%] top-1/2 -translate-y-1/2 -rotate-90 origin-center hidden xl:block">
        <span className="text-[10rem] text-white/[0.01] serif uppercase tracking-[0.6em] select-none pointer-events-none">DISCRETION</span>
      </div>

      <div className="container mx-auto px-8 max-w-7xl">
        <div className="max-w-4xl mx-auto text-center mb-40">
           <span className="text-champagne tracking-[0.8em] text-[0.6rem] uppercase mb-8 block font-bold">The Velocity Standard</span>
           <h2 className="text-5xl md:text-[8rem] text-white serif italic leading-none">Uncompromising <br /><span className="not-italic metallic-text">Excellence.</span></h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-y-32 gap-x-20">
          {pillars.map((p, i) => (
            <div key={i} className="group relative pt-12">
               {/* Large Stylized Roman Numeral */}
               <span className="text-white/[0.07] text-[12rem] md:text-[14rem] serif absolute -top-12 -left-4 md:-left-8 transition-all duration-1000 group-hover:text-white/[0.12] group-hover:-translate-y-2 select-none pointer-events-none leading-none">
                {p.num}
               </span>
               
               <div className="pl-12 md:pl-20 relative z-10 space-y-8">
                  <h3 className="text-3xl md:text-5xl text-white serif tracking-wide group-hover:text-champagne transition-colors duration-500">
                    {p.title}
                  </h3>
                  <p className="text-white/40 text-[0.6rem] md:text-[0.7rem] leading-[1.8] max-w-sm font-light uppercase tracking-[0.25em]">
                    {p.desc}
                  </p>
                  
                  {/* Subtle Accent Line */}
                  <div className="pt-8 flex">
                    <div className="h-[1px] w-12 bg-white/10 group-hover:bg-champagne/40 group-hover:w-20 transition-all duration-700"></div>
                  </div>
               </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhyVelocity;

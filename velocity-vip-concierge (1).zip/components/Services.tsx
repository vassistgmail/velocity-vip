
import React from 'react';
import { Link } from 'react-router-dom';
import { SERVICES } from '../constants';

interface ServicesProps {
  limit?: number;
}

export default function Services({ limit }: ServicesProps) {
  const displayServices = limit ? SERVICES.slice(0, limit) : SERVICES;

  return (
    <section id="services" className="py-24 bg-black scroll-mt-20">
      <div className="container mx-auto px-8">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
          <div className="max-w-2xl space-y-4">
            <span className="text-champagne tracking-[0.4em] text-[0.6rem] uppercase font-bold">Bespoke Solutions</span>
            <h2 className="text-4xl md:text-6xl text-white serif leading-tight">Beyond <span className="italic text-champagne">Transportation.</span></h2>
          </div>
          <p className="text-white/40 max-w-sm text-sm border-l border-champagne/30 pl-6">
            Velocity VIP acts as a single point of coordination for executive travel management nationwide.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {displayServices.map((service) => (
            <div key={service.id} className="relative group overflow-hidden">
               <div className="aspect-[4/5] overflow-hidden">
                 <img 
                    src={service.image} 
                    alt={service.title} 
                    className="w-full h-full object-cover grayscale transition-transform duration-1000 group-hover:scale-110 group-hover:grayscale-0"
                 />
                 <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent"></div>
               </div>
               <div className="absolute bottom-0 left-0 right-0 p-10 space-y-4">
                 <span className="text-champagne text-[0.6rem] tracking-[0.3em] uppercase font-bold">{service.category}</span>
                 <h3 className="text-3xl text-white serif">{service.title}</h3>
                 <p className="text-white/70 text-sm leading-relaxed opacity-0 group-hover:opacity-100 transition-opacity duration-500 line-clamp-3">
                   {service.description}
                 </p>
                 <div className="pt-4 overflow-hidden h-0 group-hover:h-12 transition-all duration-500">
                    <Link to="/services" className="text-champagne text-[0.65rem] tracking-widest font-bold flex items-center">
                        EXPLORE SERVICE <span className="ml-2">→</span>
                    </Link>
                 </div>
               </div>
            </div>
          ))}
        </div>

        {!limit && (
           <div className="mt-24 space-y-16">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
                 <div className="order-2 lg:order-1">
                    <h3 className="text-3xl text-white serif mb-6 italic">Nationwide Long-Distance</h3>
                    <p className="text-white/60 mb-8 leading-relaxed font-light">Cross-city or cross-state travel with uncompromising luxury. Our chauffeurs are trained for long-distance endurance and safety, ensuring your productivity never stops while on the road.</p>
                    <ul className="space-y-4 text-white/50 text-sm uppercase tracking-widest text-[0.6rem]">
                       <li className="flex items-center"><span className="w-4 h-[1px] bg-champagne mr-4"></span> Dedicated Account Management</li>
                       <li className="flex items-center"><span className="w-4 h-[1px] bg-champagne mr-4"></span> Wi-Fi Equipped Fleet for Work</li>
                       <li className="flex items-center"><span className="w-4 h-[1px] bg-champagne mr-4"></span> Refreshment & Comfort Packages</li>
                    </ul>
                 </div>
                 <div className="order-1 lg:order-2 h-96 bg-charcoal overflow-hidden">
                    <img src="https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?auto=format&fit=crop&q=80&w=1200" className="w-full h-full object-cover grayscale opacity-60 hover:opacity-100 transition-opacity duration-1000" alt="Long distance highway travel" />
                 </div>
              </div>
           </div>
        )}
      </div>
    </section>
  );
}

import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send, CheckCircle2, AlertCircle } from 'lucide-react';

/**
 * EMAIL INTEGRATION:
 * Replace this placeholder with your unique ID from Formspree.io or a similar service.
 */
const CONTACT_ENDPOINT = "https://formspree.io/f/YOUR_FORM_ID";

const ContactForm: React.FC = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: 'General Inquiry',
    message: ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError(null);

    try {
      const response = await fetch(CONTACT_ENDPOINT, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          _subject: `WEBSITE INQUIRY: ${formData.subject} from ${formData.name}`,
          ...formData,
          _timestamp: new Date().toLocaleString()
        }),
      });

      if (response.ok) {
        setIsSuccess(true);
      } else {
        const data = await response.json();
        if (data && Object.prototype.hasOwnProperty.call(data, 'errors')) {
          setError(data["errors"].map((error: any) => error["message"]).join(", "));
        } else {
          throw new Error("Electronic correspondence is temporarily delayed.");
        }
      }
    } catch (err: any) {
      console.error('Inquiry Error:', err);
      setError("Electronic correspondence is currently delayed. Please reach our 24/7 concierge at reservations@velocityvvip.com for immediate assistance.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="contact" className="py-24 bg-black">
      <div className="container mx-auto px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-20">
          <div className="lg:col-span-5 space-y-16">
            <div className="space-y-6">
              <span className="text-champagne tracking-[0.5em] text-[0.6rem] uppercase font-bold">Connect With Us</span>
              <h2 className="text-5xl md:text-7xl text-white serif italic leading-tight">Elite <br />Coordination.</h2>
              <div className="h-[1px] w-24 bg-champagne/30"></div>
              <p className="text-white/50 font-light leading-relaxed max-w-sm">
                Our 24/7 VIP Concierge desk is ready to manage your most complex travel requirements across all 50 states.
              </p>
            </div>

            <div className="space-y-10">
              <div className="flex items-start space-x-6">
                <div className="mt-1 p-3 bg-white/5 rounded-full border border-white/10">
                  <Phone size={18} className="text-champagne" />
                </div>
                <div>
                  <h4 className="text-[0.6rem] tracking-[0.3em] uppercase text-white/40 mb-1">Direct Dial</h4>
                  <a href="tel:3155310070" className="text-xl text-white serif hover:text-champagne transition-colors">(315) 531-0070</a>
                </div>
              </div>
              <div className="flex items-start space-x-6">
                <div className="mt-1 p-3 bg-white/5 rounded-full border border-white/10">
                  <Mail size={18} className="text-champagne" />
                </div>
                <div>
                  <h4 className="text-[0.6rem] tracking-[0.3em] uppercase text-white/40 mb-1">Electronic Correspondence</h4>
                  <a href="mailto:reservations@velocityvvip.com" className="text-xl text-white serif hover:text-champagne transition-colors">reservations@velocityvvip.com</a>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-7">
            {isSuccess ? (
              <div className="bg-charcoal/30 border border-white/10 p-16 text-center animate-in zoom-in duration-500 h-full flex flex-col items-center justify-center">
                <CheckCircle2 className="text-champagne mb-6" size={48} />
                <h3 className="text-3xl text-white serif italic mb-4">Message Transmitted</h3>
                <p className="text-white/40 text-sm tracking-widest uppercase mb-10">Check your inbox; we will respond within one business hour.</p>
                <button onClick={() => setIsSuccess(false)} className="text-champagne text-[0.6rem] tracking-[0.5em] uppercase font-bold border-b border-champagne pb-1">Send Another Message</button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="bg-charcoal/30 border border-white/10 p-10 md:p-16 space-y-12">
                {error && (
                  <div className="p-4 bg-red-500/10 border border-red-500/20 text-red-200 text-xs flex items-center space-x-4">
                    <AlertCircle className="shrink-0" size={16} />
                    <p>{error}</p>
                  </div>
                )}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                  <div className="space-y-2">
                    <label className="text-[0.55rem] tracking-[0.4em] uppercase text-white/30 font-bold ml-1">Name</label>
                    <input required type="text" value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} className="w-full bg-transparent border-b border-white/10 py-4 text-sm text-white focus:outline-none focus:border-champagne transition-all serif" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[0.55rem] tracking-[0.4em] uppercase text-white/30 font-bold ml-1">Email</label>
                    <input required type="email" value={formData.email} onChange={(e) => setFormData({...formData, email: e.target.value})} className="w-full bg-transparent border-b border-white/10 py-4 text-sm text-white focus:outline-none focus:border-champagne transition-all serif" />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[0.55rem] tracking-[0.4em] uppercase text-white/30 font-bold ml-1">Subject of Inquiry</label>
                  <select value={formData.subject} onChange={(e) => setFormData({...formData, subject: e.target.value})} className="w-full bg-transparent border-b border-white/10 py-4 text-sm text-white focus:outline-none focus:border-champagne appearance-none cursor-pointer serif">
                    <option className="bg-black">General Inquiry</option>
                    <option className="bg-black">Corporate Account Setup</option>
                    <option className="bg-black">Nationwide Partnership</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <label className="text-[0.55rem] tracking-[0.4em] uppercase text-white/30 font-bold ml-1">Message</label>
                  <textarea required rows={4} value={formData.message} onChange={(e) => setFormData({...formData, message: e.target.value})} className="w-full bg-transparent border-b border-white/10 py-4 text-sm text-white focus:outline-none focus:border-champagne resize-none serif"></textarea>
                </div>

                <button type="submit" disabled={isSubmitting} className="w-full py-6 border border-champagne text-champagne text-[0.7rem] tracking-[0.5em] uppercase font-bold hover:bg-champagne hover:text-black transition-all flex items-center justify-center space-x-4 disabled:opacity-50">
                  {isSubmitting ? <span>Transmitting...</span> : <><span>Transmit Message</span> <Send size={14} /></>}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactForm;
import React from 'react';
import { Link } from 'react-router-dom';
import { Instagram, Linkedin, Twitter, Phone, Mail, MapPin } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-black pt-24 pb-12 border-t border-white/5 relative overflow-hidden">
      {/* Subtle watermark logo */}
      <div className="absolute -bottom-20 -right-20 opacity-5 pointer-events-none">
          <svg width="400" height="400" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M5 5L20 35L35 5" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
      </div>

      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-16 mb-20">
          <div className="space-y-8">
            <Link to="/" className="flex flex-col group">
              <span className="text-xl font-bold tracking-[0.2em] leading-none text-white serif uppercase">VELOCITY</span>
              <div className="w-8 h-[1px] bg-champagne my-1"></div>
              <span className="text-[0.55rem] tracking-[0.4em] text-champagne uppercase font-semibold">Concierge</span>
            </Link>
            <p className="text-white/40 text-sm leading-relaxed">
              Nationwide elite transportation and travel management. For more than 15 years, we have redefined precision and movement for executives.
            </p>
            <div className="flex space-x-6 text-white/40">
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="hover:text-champagne transition-colors"><Instagram size={20} /></a>
              <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="hover:text-champagne transition-colors"><Linkedin size={20} /></a>
              <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="hover:text-champagne transition-colors"><Twitter size={20} /></a>
            </div>
          </div>

          <div>
            <h4 className="text-white font-bold tracking-[0.2em] text-[0.65rem] uppercase mb-8">Navigation</h4>
            <ul className="space-y-4">
              <li><Link to="/" className="text-white/40 hover:text-champagne transition-colors text-xs tracking-widest uppercase cursor-pointer">Home</Link></li>
              <li><Link to="/about" className="text-white/40 hover:text-champagne transition-colors text-xs tracking-widest uppercase cursor-pointer">About</Link></li>
              <li><Link to="/services" className="text-white/40 hover:text-champagne transition-colors text-xs tracking-widest uppercase cursor-pointer">Expertise</Link></li>
              <li><Link to="/fleet" className="text-white/40 hover:text-champagne transition-colors text-xs tracking-widest uppercase cursor-pointer">The Collection</Link></li>
              <li><Link to="/gallery" className="text-white/40 hover:text-champagne transition-colors text-xs tracking-widest uppercase cursor-pointer">Gallery</Link></li>
              <li><Link to="/book" className="text-white/40 hover:text-champagne transition-colors text-xs tracking-widest uppercase cursor-pointer">Reservations</Link></li>
              <li><Link to="/contact" className="text-white/40 hover:text-champagne transition-colors text-xs tracking-widest uppercase cursor-pointer">Contact</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold tracking-[0.2em] text-[0.65rem] uppercase mb-8">Connect</h4>
            <ul className="space-y-4">
              <li className="flex items-center text-white/40 text-xs tracking-widest uppercase">
                <Phone size={14} className="mr-3 text-champagne" /> <a href="tel:3155310070" className="hover:text-champagne transition-colors">(315) 531-0070</a>
              </li>
              <li className="flex items-center text-white/40 text-xs tracking-widest uppercase">
                <Mail size={14} className="mr-3 text-champagne" /> <a href="mailto:reservations@velocityvvip.com" className="hover:text-champagne transition-colors">reservations@velocityvvip.com</a>
              </li>
              <li className="flex items-start text-white/40 text-xs tracking-widest uppercase">
                <MapPin size={14} className="mr-3 text-champagne mt-0.5" /> nationwide service coverage
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold tracking-[0.2em] text-[0.65rem] uppercase mb-8">Executive Newsletter</h4>
            <div className="relative">
               <input 
                type="email" 
                placeholder="Email Address" 
                className="w-full bg-white/5 border-b border-white/10 py-3 text-xs text-white placeholder:text-white/20 focus:outline-none focus:border-champagne"
               />
               <button className="absolute right-0 top-1/2 -translate-y-1/2 text-champagne text-[0.6rem] font-bold tracking-widest uppercase cursor-pointer">Join</button>
            </div>
            <p className="text-[0.6rem] text-white/20 mt-4 uppercase tracking-[0.2em]">Travel updates for the discerning executive.</p>
          </div>
        </div>

        <div className="pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center text-[0.6rem] text-white/30 tracking-[0.2em] uppercase font-medium">
          <p>© 2025 VELOCITY VIP CONCIERGE. ALL RIGHTS RESERVED.</p>
          <div className="flex space-x-10 mt-6 md:mt-0">
            <Link to="/terms-and-conditions" className="hover:text-champagne transition-colors cursor-pointer">Terms & Conditions</Link>
            <Link to="/terms" className="hover:text-champagne transition-colors cursor-pointer">Privacy Policy</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
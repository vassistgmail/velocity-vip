
import React from 'react';
import { Link } from 'react-router-dom';

export default function Hero() {
  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden bg-black">
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&q=80&w=2400" 
          alt="Midnight Luxury Motion" 
          className="w-full h-full object-cover opacity-40 animate-subtle-zoom brightness-50"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/40"></div>
      </div>

      <div className="container mx-auto px-8 relative z-20 text-center">
        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-12 duration-1000">
          <span className="block text-[0.65rem] tracking-[0.7em] uppercase text-champagne mb-4 font-semibold">The Art of Seamless Transit</span>
          
          <h1 className="text-6xl md:text-[9rem] leading-none text-white serif italic">
            Movement <br />
            <span className="not-italic metallic-text">Perfected.</span>
          </h1>

          <div className="flex flex-col md:flex-row items-center justify-center gap-12 mt-16">
            <p className="text-white/40 text-[0.7rem] tracking-[0.2em] uppercase max-w-xs text-center md:text-left border-l border-champagne/30 pl-6">
              Executive Chauffeur <br />
              & Bespoke Concierge <br />
              Nationwide Since 2010
            </p>
            
            <Link 
              to="/fleet" 
              className="btn-luxury"
            >
              Explore the Collection
            </Link>
          </div>
        </div>
      </div>

      <div className="absolute right-10 bottom-24 hidden lg:block rotate-90 origin-right">
        <span className="text-[0.6rem] tracking-[0.8em] uppercase text-white/20">EST. TWO THOUSAND TEN</span>
      </div>
    </section>
  );
}

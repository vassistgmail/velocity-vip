
import React from 'react';

export default function Gallery() {
  const images = [
    {
      url: 'https://res.cloudinary.com/dwjg0avzx/image/upload/v1733243223/Mercedes_S_Class_Exterior_px7xxk.png',
      tag: 'The S-Class Standard'
    },
    {
      url: 'https://opulentts.com/Mercedes%20Sprinter%20Jet%20Style%20Exterior.png',
      tag: 'Private Aviation Transit'
    },
    {
      url: 'https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?auto=format&fit=crop&q=80&w=1200',
      tag: 'Midnight Logistics'
    },
    {
      url: 'https://opulentts.com/Suburban%20exterior%203.png',
      tag: 'Executive SUV'
    },
    {
      url: 'https://res.cloudinary.com/dwjg0avzx/image/upload/v1733243594/Cadillac_CT5_2025_Exterior_1_ljugdm.png',
      tag: 'Next-Gen Sedans'
    },
    {
      url: 'https://opulentts.com/Mercedes%20Limo%20Sprinter%20Exterior.png',
      tag: 'Lounge Atmosphere'
    }
  ];

  return (
    <section id="gallery" className="py-24 bg-black scroll-mt-20">
      <div className="container mx-auto px-8">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
          <div className="space-y-4">
            <span className="text-champagne tracking-[0.4em] text-[0.6rem] uppercase font-bold">The Velocity Lifestyle</span>
            <h2 className="text-4xl md:text-7xl text-white serif leading-tight">Visual <span className="italic text-champagne">Excellence.</span></h2>
          </div>
          <p className="text-white/20 text-[0.6rem] tracking-[0.2em] uppercase max-w-xs text-right hidden md:block border-r border-champagne/30 pr-6">
            A visual testament to <br /> precision and movement.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
          {images.map((img, i) => (
            <div key={i} className={`overflow-hidden group relative bg-charcoal ${i % 4 === 0 ? 'md:col-span-2 md:row-span-2 aspect-video md:aspect-auto' : 'aspect-[4/5]'}`}>
              <img 
                src={img.url} 
                alt={img.tag} 
                className="w-full h-full object-cover grayscale transition-all duration-1000 group-hover:grayscale-0 group-hover:scale-105 opacity-60 group-hover:opacity-100"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/30 to-transparent opacity-80"></div>
              
              <div className="absolute bottom-6 left-6 overflow-hidden">
                <span className="block text-[0.65rem] tracking-[0.3em] uppercase text-champagne font-bold translate-y-full group-hover:translate-y-0 transition-transform duration-500">
                  {img.tag}
                </span>
                <div className="w-6 h-[1px] bg-champagne mt-2 -translate-x-full group-hover:translate-x-0 transition-transform duration-700"></div>
              </div>

              <div className="absolute top-6 right-6">
                 <span className="text-white/10 text-xs serif italic font-light tracking-widest">
                   VP-G-{i + 1}
                 </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}


import React from 'react';

const Terms: React.FC = () => {
  return (
    <section className="py-32 bg-black min-h-screen">
      <div className="container mx-auto px-6 max-w-4xl">
        <h1 className="text-4xl md:text-6xl text-white serif mb-12">Terms & Conditions</h1>
        <div className="space-y-12 text-white/60 leading-relaxed">
          <div className="space-y-4">
             <h3 className="text-white text-xl serif">1. Reservation & Payment</h3>
             <p>All reservations must be secured with a valid credit card. Velocity VIP Concierge reserves the right to pre-authorize the full estimated fare plus a 20% security margin prior to the commencement of service.</p>
          </div>
          
          <div className="space-y-4">
             <h3 className="text-white text-xl serif">2. Cancellation Policy</h3>
             <ul className="list-disc pl-5 space-y-2">
                <li>Sedan/SUV: Cancellations must be made at least 12 hours prior to the scheduled pickup time.</li>
                <li>Sprinter/Vans: Cancellations must be made at least 48 hours prior to the scheduled pickup time.</li>
                <li>Late cancellations are subject to the full estimated fare.</li>
             </ul>
          </div>

          <div className="space-y-4">
             <h3 className="text-white text-xl serif">3. Wait Time & No-Show</h3>
             <p>Complimentary wait time of 15 minutes is provided for all point-to-point transfers. For airport arrivals, 60 minutes of complimentary wait time is provided starting from the flight's actual arrival. After the grace period, wait time is charged in 15-minute increments at the vehicle's hourly rate.</p>
          </div>

          <div className="space-y-4">
             <h3 className="text-white text-xl serif">4. Liability & Conduct</h3>
             <p>Velocity VIP Concierge is not responsible for items left in vehicles. Clients are responsible for any interior or exterior damage caused by negligence or misconduct. Our vehicles are strictly non-smoking.</p>
          </div>

          <div className="space-y-4">
             <h3 className="text-white text-xl serif">5. Nationwide Service</h3>
             <p>While Velocity VIP maintains strict quality standards across all markets, certain operational details may vary based on local municipal regulations across the United States.</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Terms;

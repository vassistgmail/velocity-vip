
import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';

const Header: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'About', href: '/about' },
    { label: 'Concierge', href: '/concierge-services' },
    { label: 'Services', href: '/services' },
    { label: 'Fleet', href: '/fleet' },
    { label: 'Gallery', href: '/gallery' },
    { label: 'Contact', href: '/contact' },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-700 ${
      scrolled ? 'bg-black/95 py-4 border-b border-white/5' : 'bg-transparent py-8'
    }`}>
      <div className="container mx-auto px-8 flex items-center justify-between">
        {/* Left Nav */}
        <nav className="hidden lg:flex items-center space-x-12">
          {navItems.slice(0, 3).map((item) => (
            <Link
              key={item.href}
              to={item.href}
              className={`text-[0.65rem] tracking-[0.4em] uppercase font-light transition-colors ${
                isActive(item.href) ? 'text-champagne' : 'text-white/60 hover:text-champagne'
              }`}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        {/* Central Logo */}
        <Link to="/" className="flex flex-col items-center group">
          <span className="text-2xl md:text-3xl tracking-[0.3em] font-light text-white serif transition-all duration-500 group-hover:tracking-[0.4em]">VELOCITY</span>
          <div className="w-12 h-[1px] bg-champagne my-1 scale-x-50 group-hover:scale-x-100 transition-transform"></div>
          <span className="text-[0.55rem] tracking-[0.6em] text-champagne uppercase font-semibold">Concierge</span>
        </Link>

        {/* Right Nav */}
        <nav className="hidden lg:flex items-center space-x-12">
          {navItems.slice(3, 5).map((item) => (
            <Link
              key={item.href}
              to={item.href}
              className={`text-[0.65rem] tracking-[0.4em] uppercase font-light transition-colors ${
                isActive(item.href) ? 'text-champagne' : 'text-white/60 hover:text-champagne'
              }`}
            >
              {item.label}
            </Link>
          ))}
          <Link
            to="/book"
            className="px-6 py-2 border border-champagne/40 text-[0.6rem] tracking-[0.3em] uppercase text-white hover:bg-champagne hover:text-black transition-all"
          >
            Book Now
          </Link>
        </nav>

        {/* Hamburger */}
        <button className="lg:hidden text-white cursor-pointer" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X strokeWidth={1.5} /> : <Menu strokeWidth={1.5} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="lg:hidden fixed inset-0 bg-black flex flex-col items-center justify-center space-y-10 animate-in fade-in duration-500">
           <Link to="/" onClick={() => setIsOpen(false)} className="text-2xl tracking-[0.3em] uppercase font-light serif text-white">Home</Link>
           {navItems.map((item) => (
            <Link
              key={item.href}
              to={item.href}
              onClick={() => setIsOpen(false)}
              className="text-2xl tracking-[0.3em] uppercase font-light serif text-white"
            >
              {item.label}
            </Link>
          ))}
          <Link
            to="/book"
            onClick={() => setIsOpen(false)}
            className="text-2xl tracking-[0.3em] uppercase font-bold text-champagne serif"
          >
            Book Now
          </Link>
          <button onClick={() => setIsOpen(false)} className="text-white/40 tracking-[0.5em] text-xs uppercase mt-8 cursor-pointer">Close</button>
        </div>
      )}
    </header>
  );
};

export default Header;
